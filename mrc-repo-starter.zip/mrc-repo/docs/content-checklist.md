# Content Checklist

Outstanding content and assets required before the site can go live.
Update this file as items are confirmed.

---

## From Simon — required before build completes

### Brand assets
- [ ] Logo — SVG format preferred
- [ ] Primary colour HEX (dark navy)
- [ ] Accent colour HEX (gold/amber)
- [ ] Font name(s) or font files
- [ ] High-resolution photography (boat, departure point, onboard, events)

### Ventrata product IDs
- [ ] City River Tour — product ID from Ventrata dashboard
- [ ] MUFC Ferry Service — product ID
- [ ] Christmas Cruises — product ID
- [ ] Santa Cruise — product ID
- [ ] Music Nights — product ID
- [ ] Party Nights — product ID
- [ ] Any additional event product IDs

### Ventrata API keys
- [ ] OCTO connection key (read-only, goes in Netlify env var)
- [ ] Checkout widget API key (goes in page HTML)

### Page content
- [ ] City River Tour — route itinerary (43 stops from GPS commentary app)
- [ ] City River Tour — full description, highlights, what's included
- [ ] MUFC Ferry — service description, matchday schedule
- [ ] Private Hire — vessel capacities, catering options, pricing guidance
- [ ] About Us — company story, team
- [ ] Our Vessels — fleet detail for each vessel (Princess Katherine, Isabella, Melody, Georgina, Joyce Too)
- [ ] FAQ — questions and answers
- [ ] Accessibility information

### Pricing (for static fallback copy)
- [ ] City River Tour — price from
- [ ] MUFC Ferry — price from
- [ ] Events — typical price from (for static copy)

---

## From Jeff — required before build starts

- [ ] CSS approach confirmed — plain CSS or Tailwind?
- [ ] GitHub repo setup confirmed
- [ ] Deployment workflow confirmed (auto-deploy from main or manual?)
- [ ] Staging/noindex approach confirmed

---

## Status

| Item | Status | Notes |
|------|--------|-------|
| Logo | Pending | SVG needed |
| Colour HEX codes | Pending | |
| Photography | Pending | Existing site photography available |
| Ventrata product IDs | Pending | Simon to retrieve from dashboard |
| OCTO key | Pending | |
| Checkout widget key | Pending | |
| Route itinerary | Pending | GPS app data exists |
| CSS approach | Pending | Jeff to confirm |
